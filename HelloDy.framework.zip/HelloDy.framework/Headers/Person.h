//
//  Person.h
//  HelloDy
//
//  Created by liuhanhao on 2018/11/15.
//  Copyright © 2018年 liuhanhao. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject

- (NSInteger)run;

@end

NS_ASSUME_NONNULL_END
